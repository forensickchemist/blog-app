import { Router } from "express";
import { body } from "express-validator";

import {
  getAllPosts,
  getPostBySlug,
  getMyPosts,
  getAdminPosts,
  createPost,
  updatePost,
  deletePost,
  getPostsByUser,
} from "../controllers/post.js";

import { protect, optionalAuth, authorize } from "../middlewares/auth.js";
import { upload } from "../config/cloudinary.js";
import validate from "../middlewares/validate.js";

const router = Router();

const postValidation = [
  body("title")
    .trim()
    .notEmpty()
    .withMessage("Title is required"),

  body("content")
    .trim()
    .notEmpty()
    .withMessage("Content is required"),
];


// PUBLIC ROUTES
// All published posts
router.get("/", getAllPosts);

// Published posts by author
router.get("/user/:username", getPostsByUser);

// AUTHENTICATED USER ROUTES
// Current user's published + draft posts
router.get("/me", protect, getMyPosts);

// ADMIN ROUTES

// All posts, including drafts
router.get(
  "/admin",
  protect,
  authorize("admin"),
  getAdminPosts
);

// SINGLE POST
router.get("/:slug", optionalAuth, getPostBySlug);


// CREATE / UPDATE / DELETE

router.post(
  "/",
  protect,
  upload.single("coverImage"),
  postValidation,
  validate,
  createPost
);

router.put(
  "/:slug",
  protect,
  upload.single("coverImage"),
  updatePost
);

router.delete(
  "/:slug",
  protect,
  deletePost
);

export default router;